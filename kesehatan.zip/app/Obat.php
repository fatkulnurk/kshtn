<?php
class Obat
{
    var $id;
    var $nama;
    var $harga;
    var $stok;
}